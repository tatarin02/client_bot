#!/bin/bash
source /root/jupyter-env/bin/activate
python /root/jupyter-env/project_outline/client_bot/bot.py

